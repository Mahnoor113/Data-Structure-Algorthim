class RemoveDuplicacy
{
public static void main(String[] args)
{
int[] a={20,20,30,40,50,50,50};
// temp is a variable
int[] temp=new int[a.length];

int j=0;
for(int i=0; i<a.length; i++)
{
if(a[i] != a[i+1])
{
temp[j]=a[i];
j++;
}
temp[j]=a[a.length-1];
for(inti=0; i<temp.length; i++)
{
System.out.print(temp[i]+" ");
}
}
}
}