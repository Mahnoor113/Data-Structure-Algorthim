class SecondLargest
{
public static void main(String[] args)
{
int[] a={6,8,2,4,3,1,5,7};
int temp;
for(int i=0; i<a.length; i++)
{
for(intj=i+1; j<a.length-1;j++)
{
if(a[i] < a[j])
temp=a[i];
a[i]=a[j];
a[i]=temp;
}
}
}
System.out.println("second largest element is: "+a[i]);
}