import java.util.Arrays;

public class CompareArrays
{
public static void main(String[] args)
{
  int[] a= {1,2,5};
  int[] b= {1,2,5);

  if(Arrays.equals(a,b))
  {
  System.out.println("Both the Arrays are EQUAL.");

  }
  else
  {
  System.out.println("Both the Arrays are NOT EQUAL.");
  }
  }